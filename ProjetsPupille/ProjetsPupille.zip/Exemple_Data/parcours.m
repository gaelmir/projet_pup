% parcours des donn�es
clear all;
close all;

F=load('SCTf02.mat'); % chargement des donn�es ( face en premier )
V=load('SCTv02.mat'); % chargement des donn�es ( vehicule en premier )

echantillonsF = F.eyedata.FSAMPLE; % R�cup�ration des �chantillons 
echantillonsV = V.eyedata.FSAMPLE;

TempsF=echantillonsF.time; % R�cup�ration du temps
TempsV=echantillonsV.time;

TempsF=TempsF-min(TempsF);%Nouvelle echelle du temps, on part de 0 
TempsV=TempsV-min(TempsV);

%plot(TempsF) % Il y a surement des poses car la courbe n'est pas continue
%plot(TempsV);